/*
 * MbedHardware
 *
 *  Created on: Aug 17, 2011
 *      Author: nucho
 */

#ifndef ROS_MBED_HARDWARE_H_
#define ROS_MBED_HARDWARE_H_

#include "mbed.h"


class MbedHardware {
  public:
    MbedHardware(PinName tx, PinName rx, long baud = 921600)
      :iostream(tx, rx){
      baud_ = baud;
      //iostream.set_blocking(true);
      t.start();
    }


    MbedHardware()
      :iostream(USBTX, USBRX) {
        baud_ = 921600;
        //iostream.set_blocking(true);
        t.start();      
    }


    void setBaud(long baud){
      this->baud_= baud;
    }

    int getBaud(){return baud_;}

    void init(){
        iostream.set_baud(baud_);
    }


    int read(){
        if (iostream.readable()) {
             iostream.read(rbuf, 1);
            return rbuf[0];
        } else {
            return -1;
        }
    };

    void write(uint8_t* data, int length) {
        //while (!iostream.writable()) {
        iostream.write(data,length);
        //}
        /* 
        for (int i=0; i<length; i++){
             iostream.putc(data[i]);
             }
             */
    }

    unsigned long time(){return  std::chrono::duration_cast<chrono::milliseconds>(t.elapsed_time()).count();}

protected:
    BufferedSerial iostream;
    int rbuf[1]={0};
    long baud_;
    Timer t;
};


#endif /* ROS_MBED_HARDWARE_H_ */
